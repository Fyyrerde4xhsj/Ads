import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertTriangle, Calculator, DollarSign } from "lucide-react";
import { toast } from "@/hooks/use-toast";

// State tax rates (can be easily updated yearly)
const STATE_TAX_RATES = {
  "Alabama": 5.0,
  "Alaska": 0.0,
  "Arizona": 4.5,
  "Arkansas": 6.5,
  "California": 5.0,
  "Colorado": 4.4,
  "Connecticut": 6.5,
  "Delaware": 6.6,
  "Florida": 0.0,
  "Georgia": 6.0,
  "Hawaii": 8.25,
  "Idaho": 6.0,
  "Illinois": 4.95,
  "Indiana": 3.23,
  "Iowa": 8.53,
  "Kansas": 5.7,
  "Kentucky": 6.0,
  "Louisiana": 4.25,
  "Maine": 7.15,
  "Maryland": 5.75,
  "Massachusetts": 5.0,
  "Michigan": 4.25,
  "Minnesota": 9.85,
  "Mississippi": 5.0,
  "Missouri": 5.4,
  "Montana": 6.75,
  "Nebraska": 6.84,
  "Nevada": 0.0,
  "New Hampshire": 0.0,
  "New Jersey": 10.75,
  "New Mexico": 5.9,
  "New York": 6.0,
  "North Carolina": 4.75,
  "North Dakota": 2.9,
  "Ohio": 3.99,
  "Oklahoma": 5.0,
  "Oregon": 9.9,
  "Pennsylvania": 3.07,
  "Rhode Island": 5.99,
  "South Carolina": 7.0,
  "South Dakota": 0.0,
  "Tennessee": 0.0,
  "Texas": 0.0,
  "Utah": 4.85,
  "Vermont": 8.75,
  "Virginia": 5.75,
  "Washington": 0.0,
  "West Virginia": 6.5,
  "Wisconsin": 7.65,
  "Wyoming": 0.0
};

// 2025 Federal Tax Brackets (Single Filer)
const FEDERAL_TAX_BRACKETS = [
  { min: 0, max: 11600, rate: 0.10 },
  { min: 11601, max: 47150, rate: 0.12 },
  { min: 47151, max: 100525, rate: 0.22 },
  { min: 100526, max: 191950, rate: 0.24 },
  { min: 191951, max: Infinity, rate: 0.32 }
];

interface TaxResults {
  federalTax: number;
  selfEmploymentTax: number;
  stateTax: number;
  totalTax: number;
}

const TaxCalculator = () => {
  const [income, setIncome] = useState("");
  const [selectedState, setSelectedState] = useState("");
  const [incomeType, setIncomeType] = useState("");
  const [results, setResults] = useState<TaxResults | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const calculateFederalTax = (income: number): number => {
    let tax = 0;
    let remainingIncome = income;

    for (const bracket of FEDERAL_TAX_BRACKETS) {
      if (remainingIncome <= 0) break;
      
      const taxableInThisBracket = Math.min(
        remainingIncome,
        bracket.max - bracket.min + 1
      );
      
      tax += taxableInThisBracket * bracket.rate;
      remainingIncome -= taxableInThisBracket;
    }

    return tax;
  };

  const calculateSelfEmploymentTax = (income: number): number => {
    return income * 0.153; // 15.3%
  };

  const calculateStateTax = (income: number, state: string): number => {
    const rate = STATE_TAX_RATES[state as keyof typeof STATE_TAX_RATES] || 0;
    return income * (rate / 100);
  };

  const validateInputs = (): boolean => {
    if (!income || parseFloat(income) <= 0) {
      toast({
        title: "Invalid Income",
        description: "Please enter a valid income amount greater than $0.",
        variant: "destructive",
      });
      return false;
    }

    if (!selectedState) {
      toast({
        title: "State Required",
        description: "Please select your state.",
        variant: "destructive",
      });
      return false;
    }

    if (!incomeType) {
      toast({
        title: "Income Type Required",
        description: "Please select your income type.",
        variant: "destructive",
      });
      return false;
    }

    return true;
  };

  const handleCalculate = async () => {
    if (!validateInputs()) return;

    setIsCalculating(true);
    
    // Add a small delay for better UX
    await new Promise(resolve => setTimeout(resolve, 500));

    const incomeAmount = parseFloat(income);
    const federalTax = calculateFederalTax(incomeAmount);
    const selfEmploymentTax = incomeType === "1099" ? calculateSelfEmploymentTax(incomeAmount) : 0;
    const stateTax = calculateStateTax(incomeAmount, selectedState);
    const totalTax = federalTax + selfEmploymentTax + stateTax;

    setResults({
      federalTax,
      selfEmploymentTax,
      stateTax,
      totalTax
    });

    toast({
      title: "Tax Estimate Calculated!",
      description: `Total estimated tax: $${totalTax.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
    });

    setIsCalculating(false);
  };

  const formatCurrency = (amount: number): string => {
    return `$${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-primary rounded-full mb-4 shadow-card">
            <Calculator className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-2">Tax Buddy Estimator</h1>
          <p className="text-xl text-muted-foreground">Calculate your 2025 tax estimate in seconds</p>
        </div>

        {/* Main Calculator Card */}
        <Card className="p-8 shadow-card hover:shadow-card-hover transition-all duration-300 bg-gradient-card border-0">
          <div className="space-y-6">
            {/* State Selection */}
            <div className="space-y-2">
              <Label htmlFor="state" className="text-base font-semibold text-foreground">
                Select Your State
              </Label>
              <Select value={selectedState} onValueChange={setSelectedState}>
                <SelectTrigger className="h-12 bg-background border-border hover:border-ring transition-colors">
                  <SelectValue placeholder="Choose your state..." />
                </SelectTrigger>
                <SelectContent className="max-h-60">
                  {Object.keys(STATE_TAX_RATES).map((state) => (
                    <SelectItem key={state} value={state}>
                      {state} ({STATE_TAX_RATES[state as keyof typeof STATE_TAX_RATES]}% state tax)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Income Input */}
            <div className="space-y-2">
              <Label htmlFor="income" className="text-base font-semibold text-foreground">
                Annual Income (USD)
              </Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
                <Input
                  id="income"
                  type="number"
                  placeholder="Enter your yearly income..."
                  value={income}
                  onChange={(e) => setIncome(e.target.value)}
                  className="h-12 pl-10 bg-background border-border hover:border-ring focus:border-ring transition-colors text-lg"
                />
              </div>
            </div>

            {/* Income Type Selection */}
            <div className="space-y-2">
              <Label htmlFor="income-type" className="text-base font-semibold text-foreground">
                Income Type
              </Label>
              <Select value={incomeType} onValueChange={setIncomeType}>
                <SelectTrigger className="h-12 bg-background border-border hover:border-ring transition-colors">
                  <SelectValue placeholder="Select your income type..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="w2">W-2 Job (Regular Employment)</SelectItem>
                  <SelectItem value="1099">1099 / Gig Work (Self-Employed, Uber, DoorDash, Freelance, etc.)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Calculate Button */}
            <Button
              onClick={handleCalculate}
              disabled={isCalculating}
              className="w-full h-14 text-lg font-semibold bg-gradient-primary hover:opacity-90 shadow-button hover:shadow-card transition-all duration-200"
            >
              {isCalculating ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Calculating...
                </>
              ) : (
                <>
                  <Calculator className="w-5 h-5 mr-2" />
                  Estimate My Tax
                </>
              )}
            </Button>
          </div>
        </Card>

        {/* Results */}
        {results && (
          <Card className="mt-8 p-8 shadow-card bg-financial-info-bg border-l-4 border-l-financial-info">
            <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center">
              <DollarSign className="w-6 h-6 mr-2 text-financial-info" />
              Your Tax Estimate Breakdown
            </h2>
            
            <div className="grid gap-4 md:grid-cols-2">
              <div className="bg-background p-4 rounded-lg border border-border">
                <p className="text-sm text-muted-foreground">Federal Tax</p>
                <p className="text-2xl font-bold text-foreground">{formatCurrency(results.federalTax)}</p>
              </div>
              
              {results.selfEmploymentTax > 0 && (
                <div className="bg-background p-4 rounded-lg border border-border">
                  <p className="text-sm text-muted-foreground">Self-Employment Tax</p>
                  <p className="text-2xl font-bold text-foreground">{formatCurrency(results.selfEmploymentTax)}</p>
                </div>
              )}
              
              <div className="bg-background p-4 rounded-lg border border-border">
                <p className="text-sm text-muted-foreground">State Tax ({selectedState})</p>
                <p className="text-2xl font-bold text-foreground">{formatCurrency(results.stateTax)}</p>
              </div>
              
              <div className="bg-financial-success-bg p-4 rounded-lg border border-financial-success md:col-span-2">
                <p className="text-sm text-financial-success font-semibold">Total Estimated Tax</p>
                <p className="text-3xl font-bold text-financial-success">{formatCurrency(results.totalTax)}</p>
                <p className="text-sm text-muted-foreground mt-1">
                  {((results.totalTax / parseFloat(income)) * 100).toFixed(1)}% of your income
                </p>
              </div>
            </div>
          </Card>
        )}

        {/* Disclaimer */}
        <Card className="mt-8 p-6 bg-financial-warning-bg border-l-4 border-l-financial-warning">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="w-6 h-6 text-financial-warning flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-foreground mb-2">Important Disclaimer</h3>
              <p className="text-sm text-muted-foreground">
                ⚠️ This tool provides estimates only and is not official tax advice. 
                Actual taxes may vary based on deductions, credits, and other factors. 
                For official tax filing, visit{" "}
                <a href="https://www.irs.gov" target="_blank" rel="noopener noreferrer" className="text-financial-info hover:underline">
                  IRS.gov
                </a>.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default TaxCalculator;