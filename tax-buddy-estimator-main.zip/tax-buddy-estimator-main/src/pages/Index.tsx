import TaxCalculator from "@/components/TaxCalculator";

const Index = () => {
  return <TaxCalculator />;
};

export default Index;
